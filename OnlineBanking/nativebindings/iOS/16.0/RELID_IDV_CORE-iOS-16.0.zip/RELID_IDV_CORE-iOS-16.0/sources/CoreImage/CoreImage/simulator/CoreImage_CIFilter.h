#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreImage_CIFilter_symbols(JSContext*);
@protocol CIFilterInstanceExports<JSExport, NSSecureCodingInstanceExports_, NSCopyingInstanceExports_>
@property (readonly,nonatomic) CIImage * outputImage;
@property (copy,nonatomic) NSString * name;
@property (readonly,nonatomic) NSArray * inputKeys;
@property (readonly,nonatomic) NSArray * outputKeys;
@property (readonly,nonatomic) NSDictionary * attributes;
-(NSString *) name;
-(void) setName: (NSString *) aString ;
-(void) setDefaults;
@end
@protocol CIFilterClassExports<JSExport, NSSecureCodingClassExports_, NSCopyingClassExports_>
@end
@protocol CIFilterCIFilterRegistryCategoryInstanceExports<JSExport>
@end
@protocol CIFilterCIFilterRegistryCategoryClassExports<JSExport>
+(CIFilter *) filterWithName: (NSString *) name ;
JSExportAs(filterWithNameKeysAndValues,
+(CIFilter *) jsfilterWithName: (NSString *) name keysAndValues: (id) key0 arguments: (NSArray *) args );
+(CIFilter *) filterWithName: (NSString *) name withInputParameters: (NSDictionary *) params ;
+(NSArray *) filterNamesInCategory: (NSString *) category ;
+(NSArray *) filterNamesInCategories: (NSArray *) categories ;
+(void) registerFilterName: (NSString *) name constructor: (id) anObject classAttributes: (NSDictionary *) attributes ;
+(NSString *) localizedNameForFilterName: (NSString *) filterName ;
+(NSString *) localizedNameForCategory: (NSString *) category ;
+(NSString *) localizedDescriptionForFilterName: (NSString *) filterName ;
+(NSURL *) localizedReferenceDocumentationForFilterName: (NSString *) filterName ;
@end
@protocol CIFilterCIFilterXMPSerializationCategoryInstanceExports<JSExport>
@end
@protocol CIFilterCIFilterXMPSerializationCategoryClassExports<JSExport>
+(NSData *) serializedXMPFromFilters: (NSArray *) filters inputImageExtent: (CGRect) extent ;
JSExportAs(filterArrayFromSerializedXMPInputImageExtentError,
+(NSArray *) jsfilterArrayFromSerializedXMP: (NSData *) xmpData inputImageExtent: (CGRect) extent error: (JSValue *) outError );
@end
@protocol CIFilterInstanceExports_<JSExport>
@property (readonly,nonatomic) CIImage * outputImage;
@end
@protocol CIFilterClassExports_<JSExport>
+(NSDictionary *) customAttributes;
@end
#pragma clang diagnostic pop