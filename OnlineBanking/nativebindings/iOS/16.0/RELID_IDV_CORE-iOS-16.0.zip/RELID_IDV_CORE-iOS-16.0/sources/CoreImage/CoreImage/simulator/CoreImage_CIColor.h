#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreImage_CIColor_symbols(JSContext*);
@protocol CIColorInstanceExports<JSExport, NSSecureCodingInstanceExports_, NSCopyingInstanceExports_>
@property (readonly) size_t numberOfComponents;
@property (readonly) CGFloat alpha;
@property (readonly) id colorSpace;
@property (readonly) CGFloat red;
@property (readonly) CGFloat green;
@property (readonly) CGFloat blue;
@property (readonly) NSString * stringRepresentation;
JSExportAs(initWithCGColor,
-(id) jsinitWithCGColor: (id) c );
JSExportAs(initWithRedGreenBlueAlpha,
-(id) jsinitWithRed: (CGFloat) r green: (CGFloat) g blue: (CGFloat) b alpha: (CGFloat) a );
JSExportAs(initWithRedGreenBlue,
-(id) jsinitWithRed: (CGFloat) r green: (CGFloat) g blue: (CGFloat) b );
JSExportAs(initWithRedGreenBlueAlphaColorSpace,
-(id) jsinitWithRed: (CGFloat) r green: (CGFloat) g blue: (CGFloat) b alpha: (CGFloat) a colorSpace: (id) colorSpace );
JSExportAs(initWithRedGreenBlueColorSpace,
-(id) jsinitWithRed: (CGFloat) r green: (CGFloat) g blue: (CGFloat) b colorSpace: (id) colorSpace );
@end
@protocol CIColorClassExports<JSExport, NSSecureCodingClassExports_, NSCopyingClassExports_>
+(id) colorWithCGColor: (id) c ;
+(id) colorWithRed: (CGFloat) r green: (CGFloat) g blue: (CGFloat) b alpha: (CGFloat) a ;
+(id) colorWithRed: (CGFloat) r green: (CGFloat) g blue: (CGFloat) b ;
+(id) colorWithRed: (CGFloat) r green: (CGFloat) g blue: (CGFloat) b alpha: (CGFloat) a colorSpace: (id) colorSpace ;
+(id) colorWithRed: (CGFloat) r green: (CGFloat) g blue: (CGFloat) b colorSpace: (id) colorSpace ;
+(id) colorWithString: (NSString *) representation ;
+(CIColor *) blackColor;
+(CIColor *) whiteColor;
+(CIColor *) grayColor;
+(CIColor *) redColor;
+(CIColor *) greenColor;
+(CIColor *) blueColor;
+(CIColor *) cyanColor;
+(CIColor *) magentaColor;
+(CIColor *) yellowColor;
+(CIColor *) clearColor;
@end
#pragma clang diagnostic pop