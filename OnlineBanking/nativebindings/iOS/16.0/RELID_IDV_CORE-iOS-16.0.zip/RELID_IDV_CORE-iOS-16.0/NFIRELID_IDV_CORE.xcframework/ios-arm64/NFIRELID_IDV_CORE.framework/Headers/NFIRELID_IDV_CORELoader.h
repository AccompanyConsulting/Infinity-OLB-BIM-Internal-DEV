#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIRELID_IDV_COREModules(JSContext* context);
JSValue* extractNFIRELID_IDV_COREStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIRELID_IDV_COREStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
