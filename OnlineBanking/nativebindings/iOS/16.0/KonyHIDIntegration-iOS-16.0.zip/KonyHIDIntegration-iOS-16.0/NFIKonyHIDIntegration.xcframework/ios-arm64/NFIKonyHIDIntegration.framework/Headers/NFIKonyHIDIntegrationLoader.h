#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIKonyHIDIntegrationModules(JSContext* context);
JSValue* extractNFIKonyHIDIntegrationStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIKonyHIDIntegrationStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
